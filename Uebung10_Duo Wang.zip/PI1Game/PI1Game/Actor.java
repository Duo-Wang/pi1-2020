/**
 * Diese abstrakte Klasse definiert die Basisklasse für alle aktiven
 * Spielobjekte, d.h. welche, die sich bewegen. Sie definiert eine
 * abstrakte Methode, die alle abgeleiteten Klassen überschreiben
 * müssen, um das Verhalten des Spielobjekts zu definieren. Sie
 * bietet außerdem eine Methode, über die abgefragt werden kann, ob
 * sich dieses Spielobjekt entsprechend der Gitterstruktur des Feldes
 * in eine bestimmte Richtung bewegen darf.
 *
 * @author Thomas Röfer
 */
abstract class Actor extends GameObject
{
    /** Das Spielfeld. */
    private final Field field;

    /**
     * Erzeugt einen neuen Akteur.
     * @param x Die x-Koordinate dieses Akteurs im Gitter.
     * @param y Die y-Koordinate dieses Akteurs im Gitter.
     * @param rotation Die Rotation dieses Akteurs (0 = rechts ... 3 = oben).
     * @param fileName Der Dateiname des Bildes, durch das dieser Akteur
     *         dargestellt wird.
     * @param field Das Spielfeld, auf dem sich dieser Akteur bewegt.
     */
    Actor(final int x, final int y, int rotation, final String fileName,
            final Field field)
    {
        super(x, y, rotation, fileName);
        this.field = field;
    }

    /**
     * Prüfen, ob der Akteur in eine bestimmte Richtung laufen darf.
     * @param direction Die geprüfte Richtung (0 = rechts ... 3 = oben).
     */
    boolean canWalk(final int direction)
    {
        return field.hasNeighbor(getX(), getY(), direction);
    }

    /**
     * Diese Methode muss überschrieben werden, um das Verhalten dieses Akteurs
     * zu definieren.
     */
    abstract void act();
}
