import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *  Angenommen : 1. NPCs -> {"child":"c", "claudius":"C", "laila":"l"}
 *               2. NPCs -> {"player-Right":"R", "player-Down":"D", "player-Left":"L", "player-Up":"U" }
 *               3. Objects -> {"goal":"G"}
 *  Die andere Sachen sind gleich wie voher.
 *  
 *  Beispiel: "field\\normal.txt"
 *  O-C-O-G
 *    |
 *  l-O-O-O
 *    |
 *  O-O-O-c-O
 *    |
 *  R-O-O
 *  
 */ 
class Level
{
// model
private final Field field;

// npcs + player
private final List<Actor> actors = new ArrayList<>();

// gameObjects
private final List<GameObject> gameObjects = new ArrayList<>();


Level(final String fileName)
{
    // Einlesen durch Buffer
    final List<String> lines = new ArrayList<String>();
    try (final BufferedReader stream = new BufferedReader(new InputStreamReader(Game.Jar.getInputStream(fileName)))) {
        String line;
        while ((line = stream.readLine()) != null) {
            lines.add(line);
        }
    }
    catch (final FileNotFoundException e) {
        throw new IllegalArgumentException("Die Level-Dateil '" + fileName + "' wurde nicht gefunden.");
    }
    catch (final IOException e) {
        throw new IllegalArgumentException("Es gab Problem beim Lesen der Dateil + '" + fileName + "'.");
    }

    // um Typ "Field" setzen.
    field = new Field(lines.toArray(new String[lines.size()]));


    // init ein Player, weil jedes Game genau ein Player enthalten muss.
    final Player player = new Player(-1000, 0, 0, field);
    actors.add(player);
    gameObjects.add(player);

    // Alle Zellen des Feldes durchlaufen
    for (int y = 0; y < lines.size(); y += 2) {
        for (int x = 0; x < lines.get(y).length(); x += 2) {
            // gültige Symbole
            final char symbol = lines.get(y).charAt(x);
            final int index = "RDLUcClGO ".indexOf(symbol);
        
        if (index == -1) {
            // ungültige Symbole
            throw new IllegalArgumentException("Die Dateil enthält ungültige Symbole '"
                            + lines.get(y).charAt(x)
                            + "' an den Postionen"
                            + " (Zeile " + (y + 1) + ", Spalte " + (x + 1) + ")"
                            + " von Gitterknoten gefunden.");
                }
        else if(index < 4) {
            // player
            // Es darf genau nur ein Player geben.
            if (player.getX() != -1000) {
                throw new IllegalArgumentException("Mehr Players in Datei '"
                        + fileName + "', Zeile " + (y + 1) + ", Spalte " + (x + 1) 
                        + " gefunden.");
            }
            player.setLocation(x / 2, y / 2);
            player.setRotation(index);
        }
        else if (index < 7) {
            // NPCs
            final Actor actor;
            if (symbol == 'c'){
                actor = new Walker(x / 2, y / 2, index % 3 + 1,"child", field, player);
            }else if(symbol == 'C'){
                actor = new Walker(x / 2, y / 2, index % 3,"claudius", field, player);
            }else{
                actor = new Walker(x / 2, y / 2, index % 3,"laila", field, player);
            }          
            actors.add(actor);
            gameObjects.add(actor);
        }
        else if (index == 7) {
            // Das Ziel einfügen.
            gameObjects.add(new GameObject(x / 2, y / 2, 0, "goal"));
        }
            }
        }

        // Felher, kein Player
        if (player.getX() == -1000) {
            throw new IllegalArgumentException("Die Dateil'" + fileName + "' enthält keinen Player!");
        }
    }
    
    /**
     *  get alle List<GameObject>
     */
    List<GameObject> getGameObjects()
    {
        return gameObjects;
    }
    

    /**
     *  alle Actors
     */
    List<Actor> getActors()
    {
        return actors;
    }
    
    /**
     * Bildschirm wird verschwinden, wenn player verschwinden hat.
     */
    void hide()
    {
        for (final GameObject gameObject : gameObjects) {
            gameObject.setVisible(false);
        }
        field.hide();
    }
}
