import java.util.ArrayList;
import java.util.List;

/**
 * main klasse mit Level klass.
 */
abstract class PI1Game extends Game
{
    /** Das Spiel beginnt durch Aufruf dieser Methode. */
    static void main()
    {
        // Das Spielfeld erzeugen
        final Level level = new Level("field\\normal.txt");
        
        level.getGameObjects().add(new GameObject(4, 0, 0, "bridge"));
        level.getGameObjects().add(new GameObject(4, 1, 3, "water-l"));
        level.getGameObjects().add(new GameObject(3, 3, 0, "water-l"));
        level.getGameObjects().add(new GameObject(4, 3, 0, "water-i"));
        
        // wenn player nicht den Game verloren hat, ausführen!
        while (level.getActors().get(0).isVisible()) {
            for (final Actor actor : level.getActors()) {
                 actor.act();
            }
        }
        level.hide();
    }
}
